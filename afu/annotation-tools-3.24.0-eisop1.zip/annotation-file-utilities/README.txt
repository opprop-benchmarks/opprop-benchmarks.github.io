Annotation File Utilities README file

For user documentation, see file annotation-file-utilities.html .

===========================================================================

Contents

The contents of this directory are:

annotation-file-utilities.html
  Annotation File Utilities documentation.
  Most users should only have to read this file.
annotation-file-format.{html,pdf}
  Describes the annotation file format.
scripts/
  Contains Unix and Windows programs for transferring annotations among
  Java, class, and annotation files.
annotation-file-utilities-all.jar
  Java library used by the programs.
build.xml, src/, lib/, tests/
  For developers only:  buildfile, source code, libraries, tests.
