public class AnnotationEnumFieldInsertion {
  void test() {
    int i = 1;
  }
}
