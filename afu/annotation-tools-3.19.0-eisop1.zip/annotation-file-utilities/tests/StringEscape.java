package annotator.tests;

public class StringEscape {
  public void foo(String orig) {}
}
