// Try to add annotations from different packages that have the same
// name.  Results should be the same whether _abbreviate_ is set to true
// or to false.
class Abbreviation {
  public Abbreviation(Object o) {}
}
