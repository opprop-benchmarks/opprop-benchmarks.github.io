package test;

class Issue155 {
  void foo() {
    B result[] = new B[2];
  }
}
