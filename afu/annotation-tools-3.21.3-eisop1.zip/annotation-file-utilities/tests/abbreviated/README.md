For motivation/explanation, see
[Issue 111](https://github.com/typetools/annotation-tools/issues/111).
(Note that `C2` in the linked issue became `C0` here because the outcome
depends on the order of the arguments, and `Makefile` passes the files
to the annotator in reverse lexicographical order.)

