public class NestedConstructorResultAnno {

  class InnerClass {}
}
