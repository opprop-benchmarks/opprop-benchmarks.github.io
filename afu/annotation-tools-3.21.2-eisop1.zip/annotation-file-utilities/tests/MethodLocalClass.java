public class MethodLocalClass {
  public void method() {
    class Local {
      Object o = null;
    }
  }
}
