package annotator.tests;

public class Varargs {

  public void m1(String... params) {}

  public void m2(String... params) {}

  public void m3(String... params) {}

  public void m4(Comparable<String>... params) {}
}
