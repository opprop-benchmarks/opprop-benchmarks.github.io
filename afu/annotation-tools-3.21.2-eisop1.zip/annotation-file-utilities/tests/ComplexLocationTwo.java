package annotator.tests;

import java.util.*;

public class ComplexLocationTwo {
  Map<Comparable<Object[][][]>, List<Date>> field;
}
