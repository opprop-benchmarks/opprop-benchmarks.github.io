package annotations.tests.classfile.cases;

import java.util.Set;

public class TestFieldGenericSmall<T> {
  Set<TestFieldGenericSmall> set;
}
