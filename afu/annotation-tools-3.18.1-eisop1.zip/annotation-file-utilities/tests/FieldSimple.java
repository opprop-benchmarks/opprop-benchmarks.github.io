package annotator.tests;

public class FieldSimple {
  private Integer field;
}
