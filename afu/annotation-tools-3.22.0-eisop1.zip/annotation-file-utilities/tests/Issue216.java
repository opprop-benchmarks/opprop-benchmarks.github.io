public class Issue216 {

  Object value;
  Object value2 = new Object();
  Issue216 t = this;
  // TODO
  // Object[] array = new Object[0];

  public Issue216() {}
}
