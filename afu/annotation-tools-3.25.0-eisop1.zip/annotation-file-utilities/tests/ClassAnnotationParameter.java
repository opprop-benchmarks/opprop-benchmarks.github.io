package annotator.tests;

public class ClassAnnotationParameter {
  public void foo() {}
}
