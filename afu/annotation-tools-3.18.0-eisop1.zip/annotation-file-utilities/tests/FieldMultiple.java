package annotator.tests;

public class FieldMultiple {
  public Integer foo, bar;
  public Integer i, d;
}
