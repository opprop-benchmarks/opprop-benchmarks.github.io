package annotator.tests;

public class ArrayParamSimple {

  public void m1(Integer[] arg) {}

  public void m2(Integer[] arg) {}

  public void m3(Integer[] arg) {}

  public void m4(Integer[] arg) {}

  public void m5(Integer[] arg) {}

  public void m6(Integer[] arg) {}

  public void m7(Integer[] arg) {}

  public void m8(Integer[] arg) {}
}
