package annotator.tests;

public class Date {
  private long t;
}
