import java.util.ArrayList;
import java.util.List;

public class NewArray {
  private static final int MAX_HOOKS = 10;
  private static final Runnable[] hooks = new Runnable[MAX_HOOKS];

  String[] names01 = new String[12];

  String[] names02 = {"Alice", "Bob"};

  String[] names03 = new String[] {"Alice", "Bob"};

  static final int[] table1 = {0, 1};
  static final int table2[] = {0, 1};

  String[][][][][] names0 = new String[11][12][13][14][15];
  String[][][][][] names1 = new String[11][12][13][14][15];
  String[][][][][] names2 = new String[11][12][13][14][15];
  String[][][][][] names3 = new String[11][12][13][14][15];
  String[][][][][] names4 = new String[11][12][13][14][15];
  String[][][][][] names5 = new String[11][12][13][14][15];

  Object names10 = new String[][][][][] {{{}}};
  Object names11 = new String[][][][][] {{{}}};
  Object names12 = new String[][][][][] {{{}}};
  Object names13 = new String[][][][][] {{{}}};
  Object names14 = new String[][][][][] {{{}}};
  Object names15 = new String[][][][][] {{{}}};

  List<?>[] lists = new ArrayList<?>[2];
}
