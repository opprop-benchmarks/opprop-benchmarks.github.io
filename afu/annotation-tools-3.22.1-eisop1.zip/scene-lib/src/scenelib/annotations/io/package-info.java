/**
 * <code>scenelib.annotations.io</code> provides classes for the input and output of {@link
 * scenelib.annotations.el.AScene}s to/from various formats.
 */
package scenelib.annotations.io;
