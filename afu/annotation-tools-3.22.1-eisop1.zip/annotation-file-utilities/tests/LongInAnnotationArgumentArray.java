class LongInAnnotationArgumentArray {
  long s0 = 2147483648L;
}
