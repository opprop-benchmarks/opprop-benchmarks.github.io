class Issue156 {
  void main() {
    int x = 10;
    int y = 20;
  }
}
