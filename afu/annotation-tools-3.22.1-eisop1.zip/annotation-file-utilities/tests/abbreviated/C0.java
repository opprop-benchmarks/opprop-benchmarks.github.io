public class C0 {}
